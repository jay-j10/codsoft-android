package com.example.quotesapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView quoteTextView;
    private Button prevButton;
    private Button nextButton;
    private int currentIndex = 0;

    private String[] quotes = {
            "The only limit to our realization of tomorrow is our doubts of today.",
            "The future belongs to those who believe in the beauty of their dreams.",
            "Do not wait to strike till the iron is hot; but make it hot by striking.",
            "The best way to predict the future is to invent it.",
            "Life is 10% what happens to us and 90% how we react to it."
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        quoteTextView = findViewById(R.id.quoteTextView);
        prevButton = findViewById(R.id.prevButton);
        nextButton = findViewById(R.id.nextButton);

        updateQuote();

        prevButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentIndex > 0) {
                    currentIndex--;
                    updateQuote();
                }
            }
        });

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentIndex < quotes.length - 1) {
                    currentIndex++;
                    updateQuote();
                }
            }
        });
    }

    private void updateQuote() {
        quoteTextView.setText(quotes[currentIndex]);
    }
}
